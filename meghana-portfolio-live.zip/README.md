# Modern Portfolio - Meghana Patnam

A complete full-stack web portfolio featuring:
- **Frontend**: Responsive HTML5, CSS Grid, Flexbox, dynamic hero, skills matrix, and college project showcases (EV Smart Charging Kiosk, Flight Schedule Generator, Gauss-Seidel Power Flow).
- **Backend**: Python Flask REST API (`/api/contact`, `/api/messages`).
- **Database**: Automated SQLite persistence (`contacts.db`) storing all incoming contact messages.
- **Production Ready**: Includes `Procfile`, `runtime.txt`, and `requirements.txt` ready for 1-click deployment on Render, Railway, PythonAnywhere, or Vercel.

---

## 🚀 How to Run Locally

### 1. Extract the ZIP
Unzip `meghana-portfolio-live.zip` and open the folder in your terminal or VS Code.

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Run the Backend
```bash
python app.py
```
Open your browser and visit: `http://127.0.0.1:5000`

---

## 🌐 How to Host Live for Free

### Option A: Render.com (Recommended for Fullstack Flask + Database)
1. Push this folder to a GitHub repository.
2. Go to [render.com](https://render.com) and create a **New Web Service**.
3. Connect your GitHub repository.
4. Set:
   - **Environment**: `Python 3`
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn app:app`
5. Click **Deploy**. Your portfolio is live with a custom HTTPS URL!

### Option B: Static Upload (Skillbridge / GitHub Pages / Netlify)
If your platform requires only static HTML/CSS, the included `index.html` file can be uploaded directly!
