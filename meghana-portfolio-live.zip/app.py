import os
import sqlite3
from datetime import datetime
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)
DB_FILE = 'contacts.db'

def init_db():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            subject TEXT NOT NULL,
            message TEXT NOT NULL,
            timestamp TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

# Initialize DB on start
init_db()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/contact', methods=['POST'])
def handle_contact():
    data = request.get_json() if request.is_json else request.form
    name = data.get('name', '').strip()
    email = data.get('email', '').strip()
    subject = data.get('subject', '').strip()
    message = data.get('message', '').strip()

    if not name or not email or not message:
        return jsonify({'status': 'error', 'message': 'Name, email, and message are required.'}), 400

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO messages (name, email, subject, message, timestamp)
        VALUES (?, ?, ?, ?, ?)
    ''', (name, email, subject, message, timestamp))
    conn.commit()
    conn.close()

    return jsonify({
        'status': 'success',
        'message': f'Thank you {name}! Your message has been received and saved.'
    }), 200

@app.route('/api/messages', methods=['GET'])
def get_messages():
    # Helper endpoint to view received contact messages
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('SELECT id, name, email, subject, message, timestamp FROM messages ORDER BY id DESC')
    rows = cursor.fetchall()
    conn.close()

    messages = [
        {'id': r[0], 'name': r[1], 'email': r[2], 'subject': r[3], 'message': r[4], 'timestamp': r[5]}
        for r in rows
    ]
    return jsonify({'messages': messages})

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
